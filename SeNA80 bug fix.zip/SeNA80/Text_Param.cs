﻿using System;
using System.Windows.Forms;

namespace SeNA80
{
    public partial class Text_Param : Form
    {
        public Text_Param()
        {
            InitializeComponent();
        }
    }
}
