﻿namespace SeNA80
{
    partial class Man_Controlcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Man_Controlcs));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_UVCellsOn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Menu_Trityl = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Cond = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label96 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.lblManStatus = new System.Windows.Forms.Label();
            this.DispVol = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Man_Status = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.AmDispVol = new System.Windows.Forms.NumericUpDown();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.btn_Recycle = new System.Windows.Forms.Button();
            this.lb_AmPres = new System.Windows.Forms.Label();
            this.l_AmPres = new System.Windows.Forms.Label();
            this.lb_RgPres = new System.Windows.Forms.Label();
            this.l_RgtPres = new System.Windows.Forms.Label();
            this.btn_InitA = new System.Windows.Forms.Button();
            this.btn_InitR = new System.Windows.Forms.Button();
            this.cb_W2_1 = new System.Windows.Forms.CheckBox();
            this.cb_W2_2 = new System.Windows.Forms.CheckBox();
            this.btn_WashB = new System.Windows.Forms.Button();
            this.btn_CapA = new System.Windows.Forms.Button();
            this.btn_Ox1 = new System.Windows.Forms.Button();
            this.btn_Ox2 = new System.Windows.Forms.Button();
            this.btn_Act1 = new System.Windows.Forms.Button();
            this.btn_Act2 = new System.Windows.Forms.Button();
            this.btn_Xtra1 = new System.Windows.Forms.Button();
            this.btn_WashA = new System.Windows.Forms.Button();
            this.btn_CapB = new System.Windows.Forms.Button();
            this.btn_GasPurge = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btn_RecWaste = new System.Windows.Forms.Button();
            this.btnPumpSel = new System.Windows.Forms.Button();
            this.btnPump = new System.Windows.Forms.Button();
            this.label56a = new System.Windows.Forms.Label();
            this.label55a = new System.Windows.Forms.Label();
            this.btnAm14 = new System.Windows.Forms.Button();
            this.label99 = new System.Windows.Forms.Label();
            this.btnColByP = new System.Windows.Forms.Button();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.btnAmPump = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.btnBypPump = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.btnCol8 = new System.Windows.Forms.Button();
            this.btnCol7 = new System.Windows.Forms.Button();
            this.btnCol6 = new System.Windows.Forms.Button();
            this.btnCol5 = new System.Windows.Forms.Button();
            this.btnCol4 = new System.Windows.Forms.Button();
            this.btnCol3 = new System.Windows.Forms.Button();
            this.btnCol2 = new System.Windows.Forms.Button();
            this.btnCol1 = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.btnAm9 = new System.Windows.Forms.Button();
            this.btnAm10 = new System.Windows.Forms.Button();
            this.btnAm11 = new System.Windows.Forms.Button();
            this.btnAm12 = new System.Windows.Forms.Button();
            this.btnAm13 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.btnAm8 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.btnAm7 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnAm6 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.btnAm5 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnAm4 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.btnAm3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnAm2 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.Am1V = new System.Windows.Forms.Label();
            this.btnAm1 = new System.Windows.Forms.Button();
            this.btn_Debl = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblXtra1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblXtra2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblWash = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DispVol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AmDispVol)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(918, 24);
            this.menuStrip1.TabIndex = 252;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_UVCellsOn,
            this.toolStripSeparator1,
            this.Menu_Trityl,
            this.Menu_Cond});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // Menu_UVCellsOn
            // 
            this.Menu_UVCellsOn.Name = "Menu_UVCellsOn";
            this.Menu_UVCellsOn.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.Menu_UVCellsOn.Size = new System.Drawing.Size(239, 22);
            this.Menu_UVCellsOn.Text = "Turn  Ce&lls On/Off";
            this.Menu_UVCellsOn.Click += new System.EventHandler(this.Menu_UVCellsOn_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(236, 6);
            // 
            // Menu_Trityl
            // 
            this.Menu_Trityl.Name = "Menu_Trityl";
            this.Menu_Trityl.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.Menu_Trityl.Size = new System.Drawing.Size(239, 22);
            this.Menu_Trityl.Text = "View &UV Strip Chart";
            this.Menu_Trityl.Click += new System.EventHandler(this.Menu_Trityl_Click);
            // 
            // Menu_Cond
            // 
            this.Menu_Cond.Enabled = false;
            this.Menu_Cond.Name = "Menu_Cond";
            this.Menu_Cond.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.Menu_Cond.Size = new System.Drawing.Size(239, 22);
            this.Menu_Cond.Text = "View &Conductivity Strip";
            this.Menu_Cond.Click += new System.EventHandler(this.Menu_Cond_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_Help,
            this.toolStripSeparator2,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // Menu_Help
            // 
            this.Menu_Help.Name = "Menu_Help";
            this.Menu_Help.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.Menu_Help.Size = new System.Drawing.Size(118, 22);
            this.Menu_Help.Text = "&Help";
            this.Menu_Help.Click += new System.EventHandler(this.Menu_Help_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(115, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.aboutToolStripMenuItem.Text = "A&bout";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(846, 299);
            this.label96.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(73, 25);
            this.label96.TabIndex = 294;
            this.label96.Text = "Waste";
            // 
            // button37
            // 
            this.button37.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button37.Location = new System.Drawing.Point(757, 451);
            this.button37.Margin = new System.Windows.Forms.Padding(2);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(100, 34);
            this.button37.TabIndex = 298;
            this.button37.Text = "Return>>";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // lblManStatus
            // 
            this.lblManStatus.AutoSize = true;
            this.lblManStatus.Location = new System.Drawing.Point(201, 482);
            this.lblManStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblManStatus.Name = "lblManStatus";
            this.lblManStatus.Size = new System.Drawing.Size(37, 13);
            this.lblManStatus.TabIndex = 300;
            this.lblManStatus.Text = "Status";
            // 
            // DispVol
            // 
            this.DispVol.Increment = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.DispVol.Location = new System.Drawing.Point(771, 172);
            this.DispVol.Margin = new System.Windows.Forms.Padding(2);
            this.DispVol.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.DispVol.Name = "DispVol";
            this.DispVol.Size = new System.Drawing.Size(55, 20);
            this.DispVol.TabIndex = 301;
            this.DispVol.ThousandsSeparator = true;
            this.DispVol.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(891, 526);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 302;
            this.label2.Text = "µL";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(868, 389);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 303;
            this.label3.Text = "Dispense";
            this.label3.Visible = false;
            // 
            // Man_Status
            // 
            this.Man_Status.Location = new System.Drawing.Point(198, 502);
            this.Man_Status.Margin = new System.Windows.Forms.Padding(2);
            this.Man_Status.MaxLength = 64767;
            this.Man_Status.Multiline = true;
            this.Man_Status.Name = "Man_Status";
            this.Man_Status.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Man_Status.Size = new System.Drawing.Size(495, 83);
            this.Man_Status.TabIndex = 299;
            this.Man_Status.WordWrap = false;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(767, 151);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(51, 13);
            this.label102.TabIndex = 317;
            this.label102.Text = "Dispense";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(832, 174);
            this.label103.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(19, 13);
            this.label103.TabIndex = 316;
            this.label103.Text = "µL";
            // 
            // AmDispVol
            // 
            this.AmDispVol.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.AmDispVol.Location = new System.Drawing.Point(827, 392);
            this.AmDispVol.Margin = new System.Windows.Forms.Padding(2);
            this.AmDispVol.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.AmDispVol.Name = "AmDispVol";
            this.AmDispVol.Size = new System.Drawing.Size(50, 20);
            this.AmDispVol.TabIndex = 315;
            this.AmDispVol.ThousandsSeparator = true;
            this.AmDispVol.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.AmDispVol.Visible = false;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(669, 129);
            this.label109.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(40, 15);
            this.label109.TabIndex = 323;
            this.label109.Text = "Pump";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(862, 406);
            this.label110.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(54, 30);
            this.label110.TabIndex = 324;
            this.label110.Text = "Reagent\r\nPump";
            this.label110.Visible = false;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.ForeColor = System.Drawing.Color.Green;
            this.label111.Location = new System.Drawing.Point(832, 456);
            this.label111.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(77, 15);
            this.label111.TabIndex = 325;
            this.label111.Text = "<<< Recycle ";
            this.label111.Visible = false;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.ForeColor = System.Drawing.Color.Green;
            this.label112.Location = new System.Drawing.Point(840, 364);
            this.label112.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(77, 15);
            this.label112.TabIndex = 326;
            this.label112.Text = "<<< Recycle ";
            this.label112.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(794, 537);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 328;
            this.label5.Text = "Recycle >>>";
            this.label5.Visible = false;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.ForeColor = System.Drawing.Color.Green;
            this.label113.Location = new System.Drawing.Point(794, 563);
            this.label113.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(77, 15);
            this.label113.TabIndex = 329;
            this.label113.Text = " Recycle>>> ";
            this.label113.Visible = false;
            // 
            // btn_Recycle
            // 
            this.btn_Recycle.Location = new System.Drawing.Point(844, 344);
            this.btn_Recycle.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Recycle.Name = "btn_Recycle";
            this.btn_Recycle.Size = new System.Drawing.Size(41, 16);
            this.btn_Recycle.TabIndex = 330;
            this.btn_Recycle.Text = "&Start";
            this.btn_Recycle.UseVisualStyleBackColor = true;
            this.btn_Recycle.Visible = false;
            this.btn_Recycle.Click += new System.EventHandler(this.btn_Recycle_Click);
            // 
            // lb_AmPres
            // 
            this.lb_AmPres.AutoSize = true;
            this.lb_AmPres.Location = new System.Drawing.Point(37, 39);
            this.lb_AmPres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_AmPres.Name = "lb_AmPres";
            this.lb_AmPres.Size = new System.Drawing.Size(88, 13);
            this.lb_AmPres.TabIndex = 331;
            this.lb_AmPres.Text = "Amidite Pressure:";
            // 
            // l_AmPres
            // 
            this.l_AmPres.AutoSize = true;
            this.l_AmPres.Location = new System.Drawing.Point(129, 39);
            this.l_AmPres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_AmPres.Name = "l_AmPres";
            this.l_AmPres.Size = new System.Drawing.Size(25, 13);
            this.l_AmPres.TabIndex = 332;
            this.l_AmPres.Text = "------";
            // 
            // lb_RgPres
            // 
            this.lb_RgPres.AutoSize = true;
            this.lb_RgPres.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_RgPres.Location = new System.Drawing.Point(393, 452);
            this.lb_RgPres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_RgPres.Name = "lb_RgPres";
            this.lb_RgPres.Size = new System.Drawing.Size(95, 13);
            this.lb_RgPres.TabIndex = 333;
            this.lb_RgPres.Text = "Reagent Pressure:";
            // 
            // l_RgtPres
            // 
            this.l_RgtPres.AutoSize = true;
            this.l_RgtPres.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_RgtPres.Location = new System.Drawing.Point(497, 454);
            this.l_RgtPres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_RgtPres.Name = "l_RgtPres";
            this.l_RgtPres.Size = new System.Drawing.Size(19, 13);
            this.l_RgtPres.TabIndex = 334;
            this.l_RgtPres.Text = "----";
            // 
            // btn_InitA
            // 
            this.btn_InitA.Location = new System.Drawing.Point(826, 412);
            this.btn_InitA.Margin = new System.Windows.Forms.Padding(2);
            this.btn_InitA.Name = "btn_InitA";
            this.btn_InitA.Size = new System.Drawing.Size(53, 20);
            this.btn_InitA.TabIndex = 335;
            this.btn_InitA.Text = "Init";
            this.btn_InitA.UseVisualStyleBackColor = true;
            this.btn_InitA.Visible = false;
            this.btn_InitA.Click += new System.EventHandler(this.btn_InitA_Click);
            // 
            // btn_InitR
            // 
            this.btn_InitR.Location = new System.Drawing.Point(771, 125);
            this.btn_InitR.Margin = new System.Windows.Forms.Padding(2);
            this.btn_InitR.Name = "btn_InitR";
            this.btn_InitR.Size = new System.Drawing.Size(55, 21);
            this.btn_InitR.TabIndex = 336;
            this.btn_InitR.Text = "Init";
            this.btn_InitR.UseVisualStyleBackColor = true;
            this.btn_InitR.Click += new System.EventHandler(this.btn_InitR_Click);
            // 
            // cb_W2_1
            // 
            this.cb_W2_1.Appearance = System.Windows.Forms.Appearance.Button;
            this.cb_W2_1.BackColor = System.Drawing.Color.White;
            this.cb_W2_1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cb_W2_1.FlatAppearance.BorderSize = 0;
            this.cb_W2_1.Location = new System.Drawing.Point(73, 463);
            this.cb_W2_1.Margin = new System.Windows.Forms.Padding(1);
            this.cb_W2_1.Name = "cb_W2_1";
            this.cb_W2_1.Size = new System.Drawing.Size(17, 17);
            this.cb_W2_1.TabIndex = 338;
            this.cb_W2_1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cb_W2_1.UseVisualStyleBackColor = false;
            this.cb_W2_1.Visible = false;
            this.cb_W2_1.CheckedChanged += new System.EventHandler(this.cb_W2_1_CheckedChanged);
            this.cb_W2_1.Paint += new System.Windows.Forms.PaintEventHandler(this.cb_W2_1_Paint);
            // 
            // cb_W2_2
            // 
            this.cb_W2_2.Appearance = System.Windows.Forms.Appearance.Button;
            this.cb_W2_2.BackColor = System.Drawing.Color.White;
            this.cb_W2_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cb_W2_2.FlatAppearance.BorderSize = 0;
            this.cb_W2_2.Location = new System.Drawing.Point(105, 463);
            this.cb_W2_2.Margin = new System.Windows.Forms.Padding(1);
            this.cb_W2_2.Name = "cb_W2_2";
            this.cb_W2_2.Size = new System.Drawing.Size(17, 17);
            this.cb_W2_2.TabIndex = 339;
            this.cb_W2_2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cb_W2_2.UseVisualStyleBackColor = false;
            this.cb_W2_2.Visible = false;
            this.cb_W2_2.CheckedChanged += new System.EventHandler(this.cb_W2_2_CheckedChanged);
            this.cb_W2_2.Paint += new System.Windows.Forms.PaintEventHandler(this.cb_W2_2_Paint);
            // 
            // btn_WashB
            // 
            this.btn_WashB.BackgroundImage = global::SeNA80.Properties.Resources.L4_Boston_Round;
            this.btn_WashB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_WashB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_WashB.ForeColor = System.Drawing.Color.White;
            this.btn_WashB.Location = new System.Drawing.Point(67, 506);
            this.btn_WashB.Margin = new System.Windows.Forms.Padding(2);
            this.btn_WashB.Name = "btn_WashB";
            this.btn_WashB.Size = new System.Drawing.Size(55, 94);
            this.btn_WashB.TabIndex = 218;
            this.btn_WashB.Text = "Wash";
            this.btn_WashB.UseVisualStyleBackColor = true;
            this.btn_WashB.Click += new System.EventHandler(this.btn_WashB_Click_1);
            // 
            // btn_CapA
            // 
            this.btn_CapA.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_CapA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_CapA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CapA.ForeColor = System.Drawing.Color.White;
            this.btn_CapA.Location = new System.Drawing.Point(314, 362);
            this.btn_CapA.Margin = new System.Windows.Forms.Padding(2);
            this.btn_CapA.Name = "btn_CapA";
            this.btn_CapA.Size = new System.Drawing.Size(40, 79);
            this.btn_CapA.TabIndex = 183;
            this.btn_CapA.Text = "Cap\r\nA";
            this.btn_CapA.UseVisualStyleBackColor = true;
            this.btn_CapA.Click += new System.EventHandler(this.btn_CapA_Click);
            // 
            // btn_Ox1
            // 
            this.btn_Ox1.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_Ox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Ox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ox1.ForeColor = System.Drawing.Color.White;
            this.btn_Ox1.Location = new System.Drawing.Point(369, 362);
            this.btn_Ox1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Ox1.Name = "btn_Ox1";
            this.btn_Ox1.Size = new System.Drawing.Size(40, 79);
            this.btn_Ox1.TabIndex = 177;
            this.btn_Ox1.Text = "Oxidize\r\n(Ox)";
            this.btn_Ox1.UseVisualStyleBackColor = true;
            this.btn_Ox1.Click += new System.EventHandler(this.btn_Ox1_Click);
            // 
            // btn_Ox2
            // 
            this.btn_Ox2.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_Ox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Ox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ox2.ForeColor = System.Drawing.Color.White;
            this.btn_Ox2.Location = new System.Drawing.Point(426, 362);
            this.btn_Ox2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Ox2.Name = "btn_Ox2";
            this.btn_Ox2.Size = new System.Drawing.Size(40, 79);
            this.btn_Ox2.TabIndex = 174;
            this.btn_Ox2.Text = "Thiol";
            this.btn_Ox2.UseVisualStyleBackColor = true;
            this.btn_Ox2.Click += new System.EventHandler(this.btn_Ox2_Click);
            // 
            // btn_Act1
            // 
            this.btn_Act1.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_Act1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Act1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Act1.ForeColor = System.Drawing.Color.White;
            this.btn_Act1.Location = new System.Drawing.Point(485, 362);
            this.btn_Act1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Act1.Name = "btn_Act1";
            this.btn_Act1.Size = new System.Drawing.Size(40, 79);
            this.btn_Act1.TabIndex = 219;
            this.btn_Act1.Text = "Act\r\n1\r\n";
            this.btn_Act1.UseVisualStyleBackColor = true;
            this.btn_Act1.Click += new System.EventHandler(this.btn_Act1_Click);
            // 
            // btn_Act2
            // 
            this.btn_Act2.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_Act2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Act2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Act2.ForeColor = System.Drawing.Color.White;
            this.btn_Act2.Location = new System.Drawing.Point(542, 362);
            this.btn_Act2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Act2.Name = "btn_Act2";
            this.btn_Act2.Size = new System.Drawing.Size(40, 79);
            this.btn_Act2.TabIndex = 232;
            this.btn_Act2.Text = "Act\r\n2";
            this.btn_Act2.UseVisualStyleBackColor = true;
            this.btn_Act2.Click += new System.EventHandler(this.btn_Act2_Click);
            // 
            // btn_Xtra1
            // 
            this.btn_Xtra1.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_Xtra1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Xtra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xtra1.ForeColor = System.Drawing.Color.White;
            this.btn_Xtra1.Location = new System.Drawing.Point(607, 362);
            this.btn_Xtra1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Xtra1.Name = "btn_Xtra1";
            this.btn_Xtra1.Size = new System.Drawing.Size(40, 79);
            this.btn_Xtra1.TabIndex = 171;
            this.btn_Xtra1.Text = "DEA";
            this.btn_Xtra1.UseVisualStyleBackColor = true;
            this.btn_Xtra1.Click += new System.EventHandler(this.btn_Xtra1_Click);
            // 
            // btn_WashA
            // 
            this.btn_WashA.BackgroundImage = global::SeNA80.Properties.Resources.L4_Boston_Round;
            this.btn_WashA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_WashA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_WashA.ForeColor = System.Drawing.Color.White;
            this.btn_WashA.Location = new System.Drawing.Point(664, 362);
            this.btn_WashA.Margin = new System.Windows.Forms.Padding(2);
            this.btn_WashA.Name = "btn_WashA";
            this.btn_WashA.Size = new System.Drawing.Size(55, 94);
            this.btn_WashA.TabIndex = 165;
            this.btn_WashA.Text = "Wash";
            this.btn_WashA.UseVisualStyleBackColor = true;
            this.btn_WashA.Click += new System.EventHandler(this.btn_WashA_Click);
            // 
            // btn_CapB
            // 
            this.btn_CapB.BackgroundImage = global::SeNA80.Properties.Resources.L1_Boston_Round;
            this.btn_CapB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_CapB.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CapB.ForeColor = System.Drawing.Color.White;
            this.btn_CapB.Location = new System.Drawing.Point(135, 441);
            this.btn_CapB.Margin = new System.Windows.Forms.Padding(2);
            this.btn_CapB.Name = "btn_CapB";
            this.btn_CapB.Size = new System.Drawing.Size(40, 61);
            this.btn_CapB.TabIndex = 180;
            this.btn_CapB.Text = "Cap\r\nB";
            this.btn_CapB.UseVisualStyleBackColor = true;
            this.btn_CapB.Click += new System.EventHandler(this.btn_CapB_Click);
            // 
            // btn_GasPurge
            // 
            this.btn_GasPurge.BackgroundImage = global::SeNA80.Properties.Resources.Ballon_90;
            this.btn_GasPurge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_GasPurge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GasPurge.ForeColor = System.Drawing.Color.White;
            this.btn_GasPurge.Location = new System.Drawing.Point(11, 448);
            this.btn_GasPurge.Margin = new System.Windows.Forms.Padding(2);
            this.btn_GasPurge.Name = "btn_GasPurge";
            this.btn_GasPurge.Size = new System.Drawing.Size(44, 54);
            this.btn_GasPurge.TabIndex = 168;
            this.btn_GasPurge.Text = "&Gas";
            this.btn_GasPurge.UseVisualStyleBackColor = true;
            this.btn_GasPurge.Click += new System.EventHandler(this.btn_GasPurge_Click);
            // 
            // label48
            // 
            this.label48.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label48.Location = new System.Drawing.Point(127, 66);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(4, 37);
            this.label48.TabIndex = 337;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.Color.White;
            this.label114.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label114.Location = new System.Drawing.Point(623, 307);
            this.label114.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(93, 5);
            this.label114.TabIndex = 327;
            this.label114.Text = "                                                         ";
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.White;
            this.label108.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label108.Location = new System.Drawing.Point(736, 471);
            this.label108.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(182, 5);
            this.label108.TabIndex = 322;
            this.label108.Text = "                                                         ";
            this.label108.Visible = false;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.Color.White;
            this.label107.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label107.Location = new System.Drawing.Point(834, 378);
            this.label107.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(81, 5);
            this.label107.TabIndex = 321;
            this.label107.Text = "                                                         ";
            this.label107.Visible = false;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.Color.White;
            this.label106.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label106.Location = new System.Drawing.Point(839, 558);
            this.label106.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(24, 5);
            this.label106.TabIndex = 320;
            this.label106.Text = "                                                         ";
            this.label106.Visible = false;
            // 
            // label105
            // 
            this.label105.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label105.Location = new System.Drawing.Point(808, 489);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(4, 34);
            this.label105.TabIndex = 319;
            this.label105.Visible = false;
            // 
            // label104
            // 
            this.label104.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label104.Location = new System.Drawing.Point(713, 232);
            this.label104.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(4, 78);
            this.label104.TabIndex = 318;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.White;
            this.label101.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label101.Location = new System.Drawing.Point(826, 526);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(51, 5);
            this.label101.TabIndex = 314;
            this.label101.Text = "                                                         ";
            this.label101.Visible = false;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.Color.White;
            this.label100.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label100.Location = new System.Drawing.Point(814, 551);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(51, 5);
            this.label100.TabIndex = 313;
            this.label100.Text = "                                                         ";
            this.label100.Visible = false;
            // 
            // label17
            // 
            this.label17.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label17.Location = new System.Drawing.Point(842, 475);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(4, 22);
            this.label17.TabIndex = 312;
            this.label17.Visible = false;
            // 
            // btn_RecWaste
            // 
            this.btn_RecWaste.BackgroundImage = global::SeNA80.Properties.Resources.way3_valve_up;
            this.btn_RecWaste.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_RecWaste.Enabled = false;
            this.btn_RecWaste.Location = new System.Drawing.Point(870, 541);
            this.btn_RecWaste.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RecWaste.Name = "btn_RecWaste";
            this.btn_RecWaste.Size = new System.Drawing.Size(34, 31);
            this.btn_RecWaste.TabIndex = 310;
            this.btn_RecWaste.UseVisualStyleBackColor = true;
            this.btn_RecWaste.Visible = false;
            this.btn_RecWaste.Click += new System.EventHandler(this.btn_RecWaste_Click);
            // 
            // btnPumpSel
            // 
            this.btnPumpSel.BackgroundImage = global::SeNA80.Properties.Resources.way3_valve_up;
            this.btnPumpSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPumpSel.Location = new System.Drawing.Point(812, 442);
            this.btnPumpSel.Margin = new System.Windows.Forms.Padding(2);
            this.btnPumpSel.Name = "btnPumpSel";
            this.btnPumpSel.Size = new System.Drawing.Size(34, 31);
            this.btnPumpSel.TabIndex = 309;
            this.btnPumpSel.UseVisualStyleBackColor = true;
            this.btnPumpSel.Visible = false;
            this.btnPumpSel.Click += new System.EventHandler(this.btnPumpSel_Click);
            // 
            // btnPump
            // 
            this.btnPump.BackgroundImage = global::SeNA80.Properties.Resources.Pump;
            this.btnPump.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPump.Enabled = false;
            this.btnPump.Location = new System.Drawing.Point(690, 147);
            this.btnPump.Margin = new System.Windows.Forms.Padding(2);
            this.btnPump.Name = "btnPump";
            this.btnPump.Size = new System.Drawing.Size(68, 88);
            this.btnPump.TabIndex = 308;
            this.btnPump.UseVisualStyleBackColor = true;
            this.btnPump.Click += new System.EventHandler(this.btnPump_Click);
            // 
            // label56a
            // 
            this.label56a.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label56a.Location = new System.Drawing.Point(152, 378);
            this.label56a.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56a.Name = "label56a";
            this.label56a.Size = new System.Drawing.Size(4, 12);
            this.label56a.TabIndex = 307;
            this.label56a.Visible = false;
            // 
            // label55a
            // 
            this.label55a.BackColor = System.Drawing.Color.White;
            this.label55a.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label55a.Location = new System.Drawing.Point(130, 378);
            this.label55a.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55a.Name = "label55a";
            this.label55a.Size = new System.Drawing.Size(26, 5);
            this.label55a.TabIndex = 306;
            this.label55a.Text = "                                                         ";
            this.label55a.Visible = false;
            // 
            // btnAm14
            // 
            this.btnAm14.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm14.ForeColor = System.Drawing.Color.White;
            this.btnAm14.Location = new System.Drawing.Point(141, 382);
            this.btnAm14.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm14.Name = "btnAm14";
            this.btnAm14.Size = new System.Drawing.Size(25, 37);
            this.btnAm14.TabIndex = 305;
            this.btnAm14.Text = "14";
            this.btnAm14.UseVisualStyleBackColor = true;
            this.btnAm14.Visible = false;
            this.btnAm14.Click += new System.EventHandler(this.btnAm14_Click);
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.Color.White;
            this.label99.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label99.Location = new System.Drawing.Point(712, 307);
            this.label99.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(135, 5);
            this.label99.TabIndex = 304;
            this.label99.Text = "                                                         ";
            // 
            // btnColByP
            // 
            this.btnColByP.BackgroundImage = global::SeNA80.Properties.Resources.way3_valve_up;
            this.btnColByP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnColByP.Location = new System.Drawing.Point(346, 291);
            this.btnColByP.Margin = new System.Windows.Forms.Padding(2);
            this.btnColByP.Name = "btnColByP";
            this.btnColByP.Size = new System.Drawing.Size(34, 31);
            this.btnColByP.TabIndex = 297;
            this.btnColByP.UseVisualStyleBackColor = true;
            this.btnColByP.Click += new System.EventHandler(this.btnColByP_Click);
            // 
            // label98
            // 
            this.label98.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label98.Location = new System.Drawing.Point(548, 125);
            this.label98.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(4, 186);
            this.label98.TabIndex = 296;
            // 
            // label97
            // 
            this.label97.BackColor = System.Drawing.Color.White;
            this.label97.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label97.Location = new System.Drawing.Point(562, 108);
            this.label97.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(157, 5);
            this.label97.TabIndex = 295;
            this.label97.Text = "                                                         ";
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.Color.White;
            this.label95.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label95.Location = new System.Drawing.Point(548, 307);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(156, 5);
            this.label95.TabIndex = 293;
            this.label95.Text = "                                                         ";
            // 
            // label94
            // 
            this.label94.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label94.Location = new System.Drawing.Point(715, 109);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(4, 37);
            this.label94.TabIndex = 292;
            // 
            // label93
            // 
            this.label93.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label93.Location = new System.Drawing.Point(817, 483);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(4, 62);
            this.label93.TabIndex = 291;
            this.label93.Visible = false;
            // 
            // btnAmPump
            // 
            this.btnAmPump.BackgroundImage = global::SeNA80.Properties.Resources.Pump;
            this.btnAmPump.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAmPump.Enabled = false;
            this.btnAmPump.Location = new System.Drawing.Point(851, 428);
            this.btnAmPump.Margin = new System.Windows.Forms.Padding(2);
            this.btnAmPump.Name = "btnAmPump";
            this.btnAmPump.Size = new System.Drawing.Size(68, 88);
            this.btnAmPump.TabIndex = 290;
            this.btnAmPump.UseVisualStyleBackColor = true;
            this.btnAmPump.Visible = false;
            this.btnAmPump.Click += new System.EventHandler(this.btnAMPump_Click);
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.White;
            this.label92.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label92.Location = new System.Drawing.Point(366, 108);
            this.label92.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(170, 5);
            this.label92.TabIndex = 289;
            this.label92.Text = "                                                         ";
            // 
            // label91
            // 
            this.label91.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label91.Location = new System.Drawing.Point(366, 109);
            this.label91.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(4, 34);
            this.label91.TabIndex = 288;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.White;
            this.label90.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label90.Location = new System.Drawing.Point(373, 307);
            this.label90.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(182, 5);
            this.label90.TabIndex = 287;
            this.label90.Text = "                                                         ";
            // 
            // btnBypPump
            // 
            this.btnBypPump.BackgroundImage = global::SeNA80.Properties.Resources.way3_valve_dn;
            this.btnBypPump.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBypPump.Location = new System.Drawing.Point(532, 97);
            this.btnBypPump.Margin = new System.Windows.Forms.Padding(2);
            this.btnBypPump.Name = "btnBypPump";
            this.btnBypPump.Size = new System.Drawing.Size(34, 31);
            this.btnBypPump.TabIndex = 286;
            this.btnBypPump.UseVisualStyleBackColor = true;
            this.btnBypPump.Click += new System.EventHandler(this.btnBypPump_Click);
            // 
            // label89
            // 
            this.label89.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label89.Location = new System.Drawing.Point(361, 241);
            this.label89.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(4, 60);
            this.label89.TabIndex = 285;
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.Color.White;
            this.label88.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label88.Location = new System.Drawing.Point(211, 306);
            this.label88.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(152, 5);
            this.label88.TabIndex = 284;
            this.label88.Text = "                                                         ";
            // 
            // label87
            // 
            this.label87.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label87.Location = new System.Drawing.Point(211, 306);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(4, 32);
            this.label87.TabIndex = 283;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.Black;
            this.label86.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label86.Location = new System.Drawing.Point(258, 140);
            this.label86.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(264, 11);
            this.label86.TabIndex = 281;
            this.label86.Text = "                                                         ";
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.Color.Black;
            this.label85.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label85.Location = new System.Drawing.Point(258, 232);
            this.label85.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(264, 11);
            this.label85.TabIndex = 280;
            this.label85.Text = "                                                         ";
            // 
            // label77
            // 
            this.label77.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label77.Location = new System.Drawing.Point(517, 148);
            this.label77.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(5, 25);
            this.label77.TabIndex = 279;
            // 
            // label78
            // 
            this.label78.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label78.Location = new System.Drawing.Point(478, 148);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(5, 25);
            this.label78.TabIndex = 278;
            // 
            // label79
            // 
            this.label79.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label79.Location = new System.Drawing.Point(442, 148);
            this.label79.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(5, 25);
            this.label79.TabIndex = 277;
            // 
            // label80
            // 
            this.label80.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label80.Location = new System.Drawing.Point(406, 148);
            this.label80.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(5, 25);
            this.label80.TabIndex = 276;
            // 
            // label81
            // 
            this.label81.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label81.Location = new System.Drawing.Point(368, 148);
            this.label81.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(5, 25);
            this.label81.TabIndex = 275;
            // 
            // label82
            // 
            this.label82.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label82.Location = new System.Drawing.Point(331, 148);
            this.label82.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(5, 25);
            this.label82.TabIndex = 274;
            // 
            // label83
            // 
            this.label83.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label83.Location = new System.Drawing.Point(295, 148);
            this.label83.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(5, 25);
            this.label83.TabIndex = 273;
            // 
            // label84
            // 
            this.label84.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label84.Location = new System.Drawing.Point(258, 148);
            this.label84.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(5, 25);
            this.label84.TabIndex = 272;
            // 
            // label73
            // 
            this.label73.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label73.Location = new System.Drawing.Point(406, 213);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(5, 25);
            this.label73.TabIndex = 271;
            // 
            // label74
            // 
            this.label74.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label74.Location = new System.Drawing.Point(443, 213);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(5, 25);
            this.label74.TabIndex = 270;
            // 
            // label75
            // 
            this.label75.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label75.Location = new System.Drawing.Point(480, 212);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(5, 25);
            this.label75.TabIndex = 269;
            // 
            // label76
            // 
            this.label76.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label76.Location = new System.Drawing.Point(517, 212);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(5, 25);
            this.label76.TabIndex = 268;
            // 
            // label71
            // 
            this.label71.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label71.Location = new System.Drawing.Point(331, 212);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(5, 25);
            this.label71.TabIndex = 267;
            // 
            // label72
            // 
            this.label72.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label72.Location = new System.Drawing.Point(369, 213);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(5, 25);
            this.label72.TabIndex = 266;
            // 
            // label70
            // 
            this.label70.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label70.Location = new System.Drawing.Point(295, 212);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(5, 25);
            this.label70.TabIndex = 265;
            // 
            // label69
            // 
            this.label69.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label69.Location = new System.Drawing.Point(258, 210);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(5, 25);
            this.label69.TabIndex = 264;
            // 
            // label68
            // 
            this.label68.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label68.Location = new System.Drawing.Point(65, 64);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(4, 19);
            this.label68.TabIndex = 263;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.White;
            this.label67.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label67.Location = new System.Drawing.Point(66, 63);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(149, 5);
            this.label67.TabIndex = 262;
            this.label67.Text = "                                                         ";
            // 
            // label66
            // 
            this.label66.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label66.Location = new System.Drawing.Point(211, 66);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(4, 245);
            this.label66.TabIndex = 261;
            // 
            // btnCol8
            // 
            this.btnCol8.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol8.ForeColor = System.Drawing.Color.Black;
            this.btnCol8.Location = new System.Drawing.Point(502, 165);
            this.btnCol8.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol8.Name = "btnCol8";
            this.btnCol8.Size = new System.Drawing.Size(35, 54);
            this.btnCol8.TabIndex = 260;
            this.btnCol8.Text = "C8";
            this.btnCol8.UseVisualStyleBackColor = true;
            this.btnCol8.Click += new System.EventHandler(this.btnCol8_Click);
            // 
            // btnCol7
            // 
            this.btnCol7.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol7.ForeColor = System.Drawing.Color.Black;
            this.btnCol7.Location = new System.Drawing.Point(464, 165);
            this.btnCol7.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol7.Name = "btnCol7";
            this.btnCol7.Size = new System.Drawing.Size(35, 54);
            this.btnCol7.TabIndex = 259;
            this.btnCol7.Text = "C7";
            this.btnCol7.UseVisualStyleBackColor = true;
            this.btnCol7.Click += new System.EventHandler(this.btnCol7_Click);
            // 
            // btnCol6
            // 
            this.btnCol6.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol6.ForeColor = System.Drawing.Color.Black;
            this.btnCol6.Location = new System.Drawing.Point(428, 165);
            this.btnCol6.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol6.Name = "btnCol6";
            this.btnCol6.Size = new System.Drawing.Size(35, 54);
            this.btnCol6.TabIndex = 258;
            this.btnCol6.Text = "C6";
            this.btnCol6.UseVisualStyleBackColor = true;
            this.btnCol6.Click += new System.EventHandler(this.btnCol6_Click);
            // 
            // btnCol5
            // 
            this.btnCol5.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol5.ForeColor = System.Drawing.Color.Black;
            this.btnCol5.Location = new System.Drawing.Point(391, 165);
            this.btnCol5.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol5.Name = "btnCol5";
            this.btnCol5.Size = new System.Drawing.Size(35, 54);
            this.btnCol5.TabIndex = 257;
            this.btnCol5.Text = "C5";
            this.btnCol5.UseVisualStyleBackColor = true;
            this.btnCol5.Click += new System.EventHandler(this.btnCol5_Click);
            // 
            // btnCol4
            // 
            this.btnCol4.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol4.ForeColor = System.Drawing.Color.Black;
            this.btnCol4.Location = new System.Drawing.Point(354, 165);
            this.btnCol4.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol4.Name = "btnCol4";
            this.btnCol4.Size = new System.Drawing.Size(35, 54);
            this.btnCol4.TabIndex = 256;
            this.btnCol4.Text = "C4";
            this.btnCol4.UseVisualStyleBackColor = true;
            this.btnCol4.Click += new System.EventHandler(this.btnCol4_Click);
            // 
            // btnCol3
            // 
            this.btnCol3.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol3.ForeColor = System.Drawing.Color.Black;
            this.btnCol3.Location = new System.Drawing.Point(316, 165);
            this.btnCol3.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol3.Name = "btnCol3";
            this.btnCol3.Size = new System.Drawing.Size(35, 54);
            this.btnCol3.TabIndex = 255;
            this.btnCol3.Text = "C3";
            this.btnCol3.UseVisualStyleBackColor = true;
            this.btnCol3.Click += new System.EventHandler(this.btnCol3_Click);
            // 
            // btnCol2
            // 
            this.btnCol2.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol2.ForeColor = System.Drawing.Color.Black;
            this.btnCol2.Location = new System.Drawing.Point(280, 165);
            this.btnCol2.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol2.Name = "btnCol2";
            this.btnCol2.Size = new System.Drawing.Size(35, 54);
            this.btnCol2.TabIndex = 254;
            this.btnCol2.Text = "C2";
            this.btnCol2.UseVisualStyleBackColor = true;
            this.btnCol2.Click += new System.EventHandler(this.btnCol2_Click);
            // 
            // btnCol1
            // 
            this.btnCol1.BackgroundImage = global::SeNA80.Properties.Resources.Column_394;
            this.btnCol1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCol1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCol1.ForeColor = System.Drawing.Color.Black;
            this.btnCol1.Location = new System.Drawing.Point(243, 165);
            this.btnCol1.Margin = new System.Windows.Forms.Padding(2);
            this.btnCol1.Name = "btnCol1";
            this.btnCol1.Size = new System.Drawing.Size(35, 54);
            this.btnCol1.TabIndex = 253;
            this.btnCol1.Text = "C1";
            this.btnCol1.UseVisualStyleBackColor = true;
            this.btnCol1.Click += new System.EventHandler(this.btnCol1_Click);
            // 
            // label65
            // 
            this.label65.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label65.Location = new System.Drawing.Point(127, 446);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(4, 27);
            this.label65.TabIndex = 251;
            // 
            // label63
            // 
            this.label63.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label63.Location = new System.Drawing.Point(150, 151);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(4, 8);
            this.label63.TabIndex = 250;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.White;
            this.label64.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label64.Location = new System.Drawing.Point(130, 150);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(24, 5);
            this.label64.TabIndex = 249;
            this.label64.Text = "                                                         ";
            // 
            // label61
            // 
            this.label61.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label61.Location = new System.Drawing.Point(151, 193);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(4, 10);
            this.label61.TabIndex = 248;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.White;
            this.label62.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label62.Location = new System.Drawing.Point(129, 193);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(26, 5);
            this.label62.TabIndex = 247;
            this.label62.Text = "                                                         ";
            // 
            // label59
            // 
            this.label59.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label59.Location = new System.Drawing.Point(152, 239);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(4, 10);
            this.label59.TabIndex = 246;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.White;
            this.label60.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label60.Location = new System.Drawing.Point(128, 239);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(26, 5);
            this.label60.TabIndex = 245;
            this.label60.Text = "                                                         ";
            // 
            // label57
            // 
            this.label57.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label57.Location = new System.Drawing.Point(149, 283);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(4, 10);
            this.label57.TabIndex = 244;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.White;
            this.label58.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label58.Location = new System.Drawing.Point(127, 283);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(26, 5);
            this.label58.TabIndex = 243;
            this.label58.Text = "                                                         ";
            // 
            // label56
            // 
            this.label56.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label56.Location = new System.Drawing.Point(151, 331);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(4, 12);
            this.label56.TabIndex = 242;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.White;
            this.label55.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label55.Location = new System.Drawing.Point(129, 331);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(26, 5);
            this.label55.TabIndex = 241;
            this.label55.Text = "                                                         ";
            // 
            // btnAm9
            // 
            this.btnAm9.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm9.ForeColor = System.Drawing.Color.White;
            this.btnAm9.Location = new System.Drawing.Point(143, 155);
            this.btnAm9.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm9.Name = "btnAm9";
            this.btnAm9.Size = new System.Drawing.Size(25, 37);
            this.btnAm9.TabIndex = 240;
            this.btnAm9.Text = "9";
            this.btnAm9.UseVisualStyleBackColor = true;
            this.btnAm9.Click += new System.EventHandler(this.btnAm9_Click);
            // 
            // btnAm10
            // 
            this.btnAm10.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm10.ForeColor = System.Drawing.Color.White;
            this.btnAm10.Location = new System.Drawing.Point(143, 198);
            this.btnAm10.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm10.Name = "btnAm10";
            this.btnAm10.Size = new System.Drawing.Size(25, 37);
            this.btnAm10.TabIndex = 239;
            this.btnAm10.Text = "10";
            this.btnAm10.UseVisualStyleBackColor = true;
            this.btnAm10.Click += new System.EventHandler(this.btnAm10_Click);
            // 
            // btnAm11
            // 
            this.btnAm11.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm11.ForeColor = System.Drawing.Color.White;
            this.btnAm11.Location = new System.Drawing.Point(141, 243);
            this.btnAm11.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm11.Name = "btnAm11";
            this.btnAm11.Size = new System.Drawing.Size(25, 37);
            this.btnAm11.TabIndex = 238;
            this.btnAm11.Text = "11";
            this.btnAm11.UseVisualStyleBackColor = true;
            this.btnAm11.Click += new System.EventHandler(this.btnAm11_Click);
            // 
            // btnAm12
            // 
            this.btnAm12.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm12.ForeColor = System.Drawing.Color.White;
            this.btnAm12.Location = new System.Drawing.Point(141, 290);
            this.btnAm12.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm12.Name = "btnAm12";
            this.btnAm12.Size = new System.Drawing.Size(25, 37);
            this.btnAm12.TabIndex = 237;
            this.btnAm12.Text = "12";
            this.btnAm12.UseVisualStyleBackColor = true;
            this.btnAm12.Click += new System.EventHandler(this.btnAm12_Click);
            // 
            // btnAm13
            // 
            this.btnAm13.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm13.ForeColor = System.Drawing.Color.White;
            this.btnAm13.Location = new System.Drawing.Point(141, 335);
            this.btnAm13.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm13.Name = "btnAm13";
            this.btnAm13.Size = new System.Drawing.Size(25, 37);
            this.btnAm13.TabIndex = 236;
            this.btnAm13.Text = "13";
            this.btnAm13.UseVisualStyleBackColor = true;
            this.btnAm13.Click += new System.EventHandler(this.btnAm13_Click);
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.White;
            this.label47.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label47.Location = new System.Drawing.Point(64, 471);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(66, 4);
            this.label47.TabIndex = 235;
            this.label47.Text = "                                                         ";
            // 
            // label53
            // 
            this.label53.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label53.Location = new System.Drawing.Point(154, 434);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(4, 10);
            this.label53.TabIndex = 234;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.White;
            this.label54.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label54.Location = new System.Drawing.Point(130, 429);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(28, 5);
            this.label54.TabIndex = 233;
            this.label54.Text = "                                                         ";
            // 
            // label52
            // 
            this.label52.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label52.Location = new System.Drawing.Point(39, 442);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(4, 10);
            this.label52.TabIndex = 231;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label51.Location = new System.Drawing.Point(39, 441);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(28, 5);
            this.label51.TabIndex = 230;
            this.label51.Text = "                                                         ";
            // 
            // label50
            // 
            this.label50.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label50.Location = new System.Drawing.Point(94, 473);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(4, 37);
            this.label50.TabIndex = 229;
            // 
            // label49
            // 
            this.label49.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label49.Location = new System.Drawing.Point(64, 436);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(4, 38);
            this.label49.TabIndex = 228;
            // 
            // label40
            // 
            this.label40.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label40.Location = new System.Drawing.Point(127, 90);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(4, 59);
            this.label40.TabIndex = 226;
            // 
            // label41
            // 
            this.label41.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label41.Location = new System.Drawing.Point(127, 145);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(4, 54);
            this.label41.TabIndex = 225;
            // 
            // label42
            // 
            this.label42.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label42.Location = new System.Drawing.Point(127, 196);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(4, 65);
            this.label42.TabIndex = 224;
            // 
            // label43
            // 
            this.label43.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label43.Location = new System.Drawing.Point(127, 258);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(4, 53);
            this.label43.TabIndex = 223;
            // 
            // label44
            // 
            this.label44.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label44.Location = new System.Drawing.Point(127, 307);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(4, 53);
            this.label44.TabIndex = 222;
            // 
            // label45
            // 
            this.label45.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label45.Location = new System.Drawing.Point(127, 359);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(4, 53);
            this.label45.TabIndex = 221;
            // 
            // label46
            // 
            this.label46.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label46.Location = new System.Drawing.Point(127, 405);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(4, 45);
            this.label46.TabIndex = 220;
            // 
            // label39
            // 
            this.label39.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label39.Location = new System.Drawing.Point(64, 75);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(5, 53);
            this.label39.TabIndex = 217;
            // 
            // label38
            // 
            this.label38.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label38.Location = new System.Drawing.Point(64, 126);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(5, 53);
            this.label38.TabIndex = 216;
            // 
            // label37
            // 
            this.label37.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label37.Location = new System.Drawing.Point(64, 176);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(5, 53);
            this.label37.TabIndex = 215;
            // 
            // label36
            // 
            this.label36.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label36.Location = new System.Drawing.Point(64, 229);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(5, 53);
            this.label36.TabIndex = 214;
            // 
            // label35
            // 
            this.label35.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label35.Location = new System.Drawing.Point(64, 281);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(5, 53);
            this.label35.TabIndex = 213;
            // 
            // label34
            // 
            this.label34.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label34.Location = new System.Drawing.Point(64, 331);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(5, 53);
            this.label34.TabIndex = 212;
            // 
            // label33
            // 
            this.label33.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label33.Location = new System.Drawing.Point(64, 382);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(5, 59);
            this.label33.TabIndex = 211;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.White;
            this.label29.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label29.Location = new System.Drawing.Point(131, 99);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(24, 5);
            this.label29.TabIndex = 210;
            this.label29.Text = "                                                         ";
            // 
            // label30
            // 
            this.label30.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label30.Location = new System.Drawing.Point(152, 102);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(4, 13);
            this.label30.TabIndex = 209;
            // 
            // btnAm8
            // 
            this.btnAm8.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm8.ForeColor = System.Drawing.Color.White;
            this.btnAm8.Location = new System.Drawing.Point(142, 111);
            this.btnAm8.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm8.Name = "btnAm8";
            this.btnAm8.Size = new System.Drawing.Size(25, 37);
            this.btnAm8.TabIndex = 208;
            this.btnAm8.Text = "8";
            this.btnAm8.UseVisualStyleBackColor = true;
            this.btnAm8.Click += new System.EventHandler(this.btnAm8_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.White;
            this.label31.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label31.Location = new System.Drawing.Point(44, 382);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(23, 5);
            this.label31.TabIndex = 207;
            this.label31.Text = "                                                         ";
            // 
            // label32
            // 
            this.label32.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label32.Location = new System.Drawing.Point(44, 382);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(4, 12);
            this.label32.TabIndex = 206;
            // 
            // btnAm7
            // 
            this.btnAm7.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm7.ForeColor = System.Drawing.Color.White;
            this.btnAm7.Location = new System.Drawing.Point(35, 395);
            this.btnAm7.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm7.Name = "btnAm7";
            this.btnAm7.Size = new System.Drawing.Size(25, 37);
            this.btnAm7.TabIndex = 205;
            this.btnAm7.Text = "7";
            this.btnAm7.UseVisualStyleBackColor = true;
            this.btnAm7.Click += new System.EventHandler(this.btnAm7_Click);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label25.Location = new System.Drawing.Point(44, 332);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 5);
            this.label25.TabIndex = 204;
            this.label25.Text = "                                                         ";
            // 
            // label26
            // 
            this.label26.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label26.Location = new System.Drawing.Point(44, 333);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(5, 15);
            this.label26.TabIndex = 203;
            // 
            // btnAm6
            // 
            this.btnAm6.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm6.ForeColor = System.Drawing.Color.White;
            this.btnAm6.Location = new System.Drawing.Point(35, 344);
            this.btnAm6.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm6.Name = "btnAm6";
            this.btnAm6.Size = new System.Drawing.Size(25, 37);
            this.btnAm6.TabIndex = 202;
            this.btnAm6.Text = "6";
            this.btnAm6.UseVisualStyleBackColor = true;
            this.btnAm6.Click += new System.EventHandler(this.btnAm6_Click);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label27.Location = new System.Drawing.Point(43, 280);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 5);
            this.label27.TabIndex = 201;
            this.label27.Text = "                                                         ";
            // 
            // label28
            // 
            this.label28.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label28.Location = new System.Drawing.Point(43, 281);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(5, 15);
            this.label28.TabIndex = 200;
            // 
            // btnAm5
            // 
            this.btnAm5.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm5.ForeColor = System.Drawing.Color.White;
            this.btnAm5.Location = new System.Drawing.Point(35, 292);
            this.btnAm5.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm5.Name = "btnAm5";
            this.btnAm5.Size = new System.Drawing.Size(25, 37);
            this.btnAm5.TabIndex = 199;
            this.btnAm5.Text = "5";
            this.btnAm5.UseVisualStyleBackColor = true;
            this.btnAm5.Click += new System.EventHandler(this.btnAm5_Click);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label21.Location = new System.Drawing.Point(44, 227);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 5);
            this.label21.TabIndex = 198;
            this.label21.Text = "                                                         ";
            // 
            // label22
            // 
            this.label22.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label22.Location = new System.Drawing.Point(44, 229);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(4, 15);
            this.label22.TabIndex = 197;
            // 
            // btnAm4
            // 
            this.btnAm4.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm4.ForeColor = System.Drawing.Color.White;
            this.btnAm4.Location = new System.Drawing.Point(35, 240);
            this.btnAm4.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm4.Name = "btnAm4";
            this.btnAm4.Size = new System.Drawing.Size(25, 37);
            this.btnAm4.TabIndex = 196;
            this.btnAm4.Text = "4";
            this.btnAm4.UseVisualStyleBackColor = true;
            this.btnAm4.Click += new System.EventHandler(this.btnAm4_Click);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label23.Location = new System.Drawing.Point(44, 177);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 5);
            this.label23.TabIndex = 195;
            this.label23.Text = "                                                         ";
            // 
            // label24
            // 
            this.label24.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label24.Location = new System.Drawing.Point(44, 179);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(4, 15);
            this.label24.TabIndex = 194;
            // 
            // btnAm3
            // 
            this.btnAm3.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm3.ForeColor = System.Drawing.Color.White;
            this.btnAm3.Location = new System.Drawing.Point(35, 190);
            this.btnAm3.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm3.Name = "btnAm3";
            this.btnAm3.Size = new System.Drawing.Size(25, 37);
            this.btnAm3.TabIndex = 193;
            this.btnAm3.Text = "3";
            this.btnAm3.UseVisualStyleBackColor = true;
            this.btnAm3.Click += new System.EventHandler(this.btnAm3_Click);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label19.Location = new System.Drawing.Point(43, 126);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 5);
            this.label19.TabIndex = 192;
            this.label19.Text = "                                                         ";
            // 
            // label20
            // 
            this.label20.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label20.Location = new System.Drawing.Point(43, 126);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(5, 15);
            this.label20.TabIndex = 191;
            // 
            // btnAm2
            // 
            this.btnAm2.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm2.ForeColor = System.Drawing.Color.White;
            this.btnAm2.Location = new System.Drawing.Point(34, 137);
            this.btnAm2.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm2.Name = "btnAm2";
            this.btnAm2.Size = new System.Drawing.Size(25, 37);
            this.btnAm2.TabIndex = 190;
            this.btnAm2.Text = "2";
            this.btnAm2.UseVisualStyleBackColor = true;
            this.btnAm2.Click += new System.EventHandler(this.btnAm2_Click);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label18.Location = new System.Drawing.Point(43, 73);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 5);
            this.label18.TabIndex = 189;
            this.label18.Text = "                                                         ";
            // 
            // Am1V
            // 
            this.Am1V.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.Am1V.Location = new System.Drawing.Point(43, 75);
            this.Am1V.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Am1V.Name = "Am1V";
            this.Am1V.Size = new System.Drawing.Size(4, 15);
            this.Am1V.TabIndex = 188;
            // 
            // btnAm1
            // 
            this.btnAm1.BackgroundImage = global::SeNA80.Properties.Resources.amidite_btl_cr;
            this.btnAm1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAm1.ForeColor = System.Drawing.Color.White;
            this.btnAm1.Location = new System.Drawing.Point(33, 86);
            this.btnAm1.Margin = new System.Windows.Forms.Padding(2);
            this.btnAm1.Name = "btnAm1";
            this.btnAm1.Size = new System.Drawing.Size(25, 37);
            this.btnAm1.TabIndex = 187;
            this.btnAm1.Text = "1";
            this.btnAm1.UseVisualStyleBackColor = true;
            this.btnAm1.Click += new System.EventHandler(this.btnAm1_Click);
            // 
            // btn_Debl
            // 
            this.btn_Debl.BackgroundImage = global::SeNA80.Properties.Resources.L4_Boston_Round;
            this.btn_Debl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Debl.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Debl.ForeColor = System.Drawing.Color.White;
            this.btn_Debl.Location = new System.Drawing.Point(245, 362);
            this.btn_Debl.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Debl.Name = "btn_Debl";
            this.btn_Debl.Size = new System.Drawing.Size(55, 94);
            this.btn_Debl.TabIndex = 186;
            this.btn_Debl.Text = "Deblock";
            this.btn_Debl.UseVisualStyleBackColor = true;
            this.btn_Debl.Click += new System.EventHandler(this.btn_Debl_Click);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label15.Location = new System.Drawing.Point(270, 336);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(5, 37);
            this.label15.TabIndex = 185;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label16.Location = new System.Drawing.Point(212, 333);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 5);
            this.label16.TabIndex = 184;
            this.label16.Text = "                                                         ";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label13.Location = new System.Drawing.Point(331, 336);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(5, 37);
            this.label13.TabIndex = 182;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label14.Location = new System.Drawing.Point(275, 333);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 5);
            this.label14.TabIndex = 181;
            this.label14.Text = "                                                         ";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label11.Location = new System.Drawing.Point(504, 333);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(5, 37);
            this.label11.TabIndex = 179;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label12.Location = new System.Drawing.Point(344, 333);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 5);
            this.label12.TabIndex = 178;
            this.label12.Text = "                                                         ";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label9.Location = new System.Drawing.Point(387, 335);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(5, 37);
            this.label9.TabIndex = 176;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label10.Location = new System.Drawing.Point(400, 333);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 5);
            this.label10.TabIndex = 175;
            this.label10.Text = "                                                         ";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.label7.Location = new System.Drawing.Point(445, 336);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(5, 37);
            this.label7.TabIndex = 173;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label8.Location = new System.Drawing.Point(459, 333);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 5);
            this.label8.TabIndex = 172;
            this.label8.Text = "                                                         ";
            // 
            // lblXtra1
            // 
            this.lblXtra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXtra1.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.lblXtra1.Location = new System.Drawing.Point(624, 335);
            this.lblXtra1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblXtra1.Name = "lblXtra1";
            this.lblXtra1.Size = new System.Drawing.Size(5, 37);
            this.lblXtra1.TabIndex = 170;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label6.Location = new System.Drawing.Point(518, 333);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 5);
            this.label6.TabIndex = 169;
            this.label6.Text = "                                                         ";
            // 
            // lblXtra2
            // 
            this.lblXtra2.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.lblXtra2.Location = new System.Drawing.Point(559, 333);
            this.lblXtra2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblXtra2.Name = "lblXtra2";
            this.lblXtra2.Size = new System.Drawing.Size(5, 37);
            this.lblXtra2.TabIndex = 167;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Image = global::SeNA80.Properties.Resources.Horiz_Line;
            this.label4.Location = new System.Drawing.Point(575, 333);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 5);
            this.label4.TabIndex = 166;
            this.label4.Text = "                                                         ";
            // 
            // lblWash
            // 
            this.lblWash.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWash.Image = global::SeNA80.Properties.Resources.Vert_Line;
            this.lblWash.Location = new System.Drawing.Point(689, 335);
            this.lblWash.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWash.Name = "lblWash";
            this.lblWash.Size = new System.Drawing.Size(5, 37);
            this.lblWash.TabIndex = 164;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Image = global::SeNA80.Properties.Resources.Horiz_Line1;
            this.label1.Location = new System.Drawing.Point(637, 333);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 5);
            this.label1.TabIndex = 163;
            this.label1.Text = "                                                         ";
            // 
            // Man_Controlcs
            // 
            this.AccessibleDescription = " ";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Ivory;
            this.ClientSize = new System.Drawing.Size(918, 635);
            this.Controls.Add(this.cb_W2_2);
            this.Controls.Add(this.cb_W2_1);
            this.Controls.Add(this.btn_WashB);
            this.Controls.Add(this.btn_CapA);
            this.Controls.Add(this.btn_Ox1);
            this.Controls.Add(this.btn_Ox2);
            this.Controls.Add(this.btn_Act1);
            this.Controls.Add(this.btn_Act2);
            this.Controls.Add(this.btn_Xtra1);
            this.Controls.Add(this.btn_WashA);
            this.Controls.Add(this.btn_CapB);
            this.Controls.Add(this.btn_GasPurge);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.btn_InitR);
            this.Controls.Add(this.btn_InitA);
            this.Controls.Add(this.l_RgtPres);
            this.Controls.Add(this.lb_RgPres);
            this.Controls.Add(this.l_AmPres);
            this.Controls.Add(this.lb_AmPres);
            this.Controls.Add(this.btn_Recycle);
            this.Controls.Add(this.label113);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label114);
            this.Controls.Add(this.label112);
            this.Controls.Add(this.label111);
            this.Controls.Add(this.label110);
            this.Controls.Add(this.label109);
            this.Controls.Add(this.label108);
            this.Controls.Add(this.label107);
            this.Controls.Add(this.label106);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.AmDispVol);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label100);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btn_RecWaste);
            this.Controls.Add(this.btnPumpSel);
            this.Controls.Add(this.btnPump);
            this.Controls.Add(this.label56a);
            this.Controls.Add(this.label55a);
            this.Controls.Add(this.btnAm14);
            this.Controls.Add(this.label99);
            this.Controls.Add(this.Man_Status);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DispVol);
            this.Controls.Add(this.lblManStatus);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.btnColByP);
            this.Controls.Add(this.label98);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.btnAmPump);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.btnBypPump);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label80);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.btnCol8);
            this.Controls.Add(this.btnCol7);
            this.Controls.Add(this.btnCol6);
            this.Controls.Add(this.btnCol5);
            this.Controls.Add(this.btnCol4);
            this.Controls.Add(this.btnCol3);
            this.Controls.Add(this.btnCol2);
            this.Controls.Add(this.btnCol1);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.btnAm9);
            this.Controls.Add(this.btnAm10);
            this.Controls.Add(this.btnAm11);
            this.Controls.Add(this.btnAm12);
            this.Controls.Add(this.btnAm13);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.btnAm8);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.btnAm7);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.btnAm6);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.btnAm5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.btnAm4);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.btnAm3);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.btnAm2);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.Am1V);
            this.Controls.Add(this.btnAm1);
            this.Controls.Add(this.btn_Debl);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblXtra1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblXtra2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblWash);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Man_Controlcs";
            this.Text = "Manual Control";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Man_Controlcs_FormClosing);
            this.Load += new System.EventHandler(this.Man_Controlcs_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DispVol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AmDispVol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button btnAm9;
        private System.Windows.Forms.Button btnAm10;
        private System.Windows.Forms.Button btnAm11;
        private System.Windows.Forms.Button btnAm12;
        private System.Windows.Forms.Button btnAm13;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblWash;
        private System.Windows.Forms.Button btn_WashA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblXtra1;
        private System.Windows.Forms.Button btn_Xtra1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_Ox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_Ox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_CapB;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_CapA;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btn_Debl;
        private System.Windows.Forms.Button btnAm1;
        private System.Windows.Forms.Label Am1V;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnAm2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnAm3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnAm4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnAm5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnAm6;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnAm7;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnAm8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button btn_WashB;
        private System.Windows.Forms.Button btn_Act1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button btn_Act2;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button btnCol1;
        private System.Windows.Forms.Button btnCol2;
        private System.Windows.Forms.Button btnCol4;
        private System.Windows.Forms.Button btnCol3;
        private System.Windows.Forms.Button btnCol8;
        private System.Windows.Forms.Button btnCol7;
        private System.Windows.Forms.Button btnCol6;
        private System.Windows.Forms.Button btnCol5;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Button btnBypPump;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Button btnAmPump;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Button btnColByP;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Label lblManStatus;
        private System.Windows.Forms.NumericUpDown DispVol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label99;
        public System.Windows.Forms.TextBox Man_Status;
        private System.Windows.Forms.Label label56a;
        private System.Windows.Forms.Label label55a;
        private System.Windows.Forms.Button btnAm14;
        private System.Windows.Forms.Button btnPump;
        private System.Windows.Forms.Button btnPumpSel;
        private System.Windows.Forms.Button btn_RecWaste;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.NumericUpDown AmDispVol;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Button btn_Recycle;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Menu_Trityl;
        private System.Windows.Forms.ToolStripMenuItem Menu_Cond;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem Menu_UVCellsOn;
        private System.Windows.Forms.Label lb_AmPres;
        private System.Windows.Forms.Label lb_RgPres;
        public System.Windows.Forms.Label l_AmPres;
        public System.Windows.Forms.Label l_RgtPres;
        private System.Windows.Forms.ToolStripMenuItem Menu_Help;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Button btn_InitA;
        private System.Windows.Forms.Button btn_InitR;
        private System.Windows.Forms.Button btn_GasPurge;
        private System.Windows.Forms.Label lblXtra2;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.CheckBox cb_W2_1;
        private System.Windows.Forms.CheckBox cb_W2_2;
    }
}