﻿using System;
using System.Windows.Forms;

namespace SeNA80
{
    public partial class Wait_Form : Form
    {
        public Wait_Form()
        {
            InitializeComponent();
        }
    }
}
